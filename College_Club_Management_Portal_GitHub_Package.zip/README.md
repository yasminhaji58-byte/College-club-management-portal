# College Club Management Portal

Level 2 Hackathon – Fundamentals of Web Development

## Student Details
- Student Name: H. Yasmin
- Student ID: 7567a9e69382bb5b7bb4197c9fd84284
- Register Number: 25133091802522040
- Department: II-B.Sc. Computer Science
- College: Jawaharlal Nehru College for Women
- Submission Date: 22.10.2026

## Technologies
HTML, CSS, JavaScript

## Run the Project
1. Download `index.html`.
2. Open it in a web browser such as Chrome.

## Features
- Dynamically displays sample clubs
- Search and filter by club name/category
- Displays club information
- Validates registration form fields
- Demo join/leave club actions
- Responsive layout

Note: This is a front-end demonstration using sample data. It does not save registration or membership data permanently.
